<?php
require_once("PHPMailer1/class.phpmailer.php");

	function send_mail($subject,$message,$user){
		$txt = '<html>
                <head>
                
                </head>
                <body>
                <div>
                 '.$message.'
                </div>
                
                </body>
                </html>
                ';
		if(isset($user))
		{
		
		$mail = new PHPMailer;
		$mail -> clearAllRecipients();
	    $mail->isSMTP();
	    $mail->SMTPDebug = 1;
	    $mail->Host = 'smtp.gmail.com';
	    $mail->Port = 587;
	    $mail->SMTPAuth = true;
		$mail->SMTPSecure ='tls';
	    $mail->Username = '';
	    $mail->Password = '';
	    $mail->setFrom('support@itc.com', 'Sanyukta');
		$mail->AddAddress($user); //Adds a "To" address
 			
 		
	    //$mail->addAddress('vikash.mishra123@gmail.com');
	    $mail->Subject = $subject;
	    //$mail->Body = "body"];
	    $mail->msgHTML($txt, __DIR__);
	    
	    if (!$mail->send()) {
	        echo 'Mailer Error: ' . $mail->ErrorInfo;
	       
	    } else {
	        echo '<script>alert("Message sent!");</script>';
	      
	       // return true;
	        
	    }
	
	}
	}
	$emails = 'Sanyukta217@gmail.com';
	
	send_mail('Testing mail','HEllo test 123',$emails);

?>