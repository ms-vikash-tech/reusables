function callPHPFunction(fn, parameter, element, type){
	var fn=fn;
	var element = element;
	var parameter = parameter;
	var type = type;
	//alert(fn + element + parameter + type);
	$.ajax({
		method: 'post',
		url: '_function.php',
		data:{fn:fn, parameter:parameter},
		success:function(data){
			alert(data);
			//alert(JSON.stringify(element));
			if(element=='alrt'){
				Swal.fire({
				  title: data
				});
			}
			else{
				if (type == 'val') {
					$(element).val(data);
				}
				if (type == 'text') {
					$(element).text(data);
				}
				if (type == 'html') {
					$(element).html(data);
				}
			}
			
		},
		error:function(data){
			alert(JSON.stringify(data));
		}
	});
}
$(document).ready(function(){
	var ticket_no = $('#ticket_no').val();
	var email_data = [];
	email_data.push({
      email: $(this).data("email"),
      name: $(this).data('name'),
      ticket_no: $(this).data('ticket_no'),
      
     });
	data.push(ticket_no);
	data.push(message);
	data.push(email_data);
		callPHPFunction('send_mail', ticket_no, '#age_of_user', 'val');

});